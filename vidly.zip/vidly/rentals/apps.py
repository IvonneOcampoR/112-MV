from django.apps import AppConfig


class RentalsConfig(AppConfig):
    name = 'rentals'
