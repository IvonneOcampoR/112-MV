from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('rentals', '0002_movie_director'),
    ]

    operations = [
        migrations.AddField(
            model_name='movie',
            name='image_url',
            field=models.TextField(default='missing.png'),
            preserve_default=False,
        ),
    ]
